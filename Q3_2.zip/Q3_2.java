//주문정보 중에서 고객명,도서명,판매가격을 도서명 또는 고객명으로 주문 정보를 검색하여 콘솔창에 고객명 순으로 출력
//콘솔창에서 도서명 또는 고객명의 일불르 입력받아 검색되게 해야함
//[검색메뉴]
//1.도서명
//2.고객명
package test.book;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



public class Q3_2 {
	Connection con;
	public Q3_2() {
		//연결하기 위해 필요한 정보 (url,user,pwd)
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user ="c##SJHmadang";
		String pwd = "manager";
		//jdbc driver memory에 load
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이버 로드 성공");
			
			//connection 객체 생성
			con=DriverManager.getConnection(url,user,pwd);
			System.out.println("DB 연결 성공");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	// main메소드에서 runSQL(1) 을 호출, 1은 검색메뉴값 의미, 스포츠는 검색어를 의미한다.
	// searchMenu가 1이면 도서검색,2이면 고객명 검색
	public void runSQL(int searchMenu,String searchWord) {
		String sql="";
		switch (searchMenu) {
		case 1: 
			sql="select name,b.bookname,saleprice from book b,customer c, orders o "
					+ "where c.custid=o.custid and b.bookid=o.bookid "
					+ "and b.bookname like '%"+searchWord+"%' order by name" ;
			break;
		case 2:
			sql="select name,b.bookname,saleprice from book b,customer c, orders o "
					+ "where c.custid=o.custid and b.bookid=o.bookid "
					+ "and name like '%"+searchWord+"%' order by name" ;
			break;
		}
		try {
		//Connection 객체를 사용해서 문장 객체를 생성 및 반환
			Statement stmt = con.createStatement();
		//Statement 객체를 사용해서 sql 문을 실행한 후 ResultSet 집합 객체 반환
			ResultSet rs = stmt.executeQuery(sql);
		//반복문을 사용해서 ResultSet 객체의 행 개수만큼 데이터를 가져와서 콘솔에 출력
			//next()는 데이터 행을 접근할 수 있는 커서를 다음 행으로 이동시키는 기능을함.
			//실제 cursor가 가리키는 데이터행이 존재하면 true를 반환, 데이터행이 존재하지 않으면 false 반환
			while(rs.next()) {
//				System.out.println("\t고객명\t\t도서명\t\t판매가격");
//				System.out.print("\t"+rs.getString("name"));
//				System.out.print("\t"+rs.getString("bookname"));
//				System.out.println("\t"+rs.getInt("saleprice"));
				
				
			    String name = rs.getString("name");
			    String bookname = rs.getString("bookname");
			    int saleprice = rs.getInt("saleprice");

			    System.out.printf("%-15s\t%-15s\t%-10d%n", name, bookname, saleprice);
				
				
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
        Scanner input2 = new Scanner(System.in);
        Q3_2 bList = new Q3_2();
        
        while (true) {
            System.out.println("[검색메뉴]");
            System.out.println("1. 도서명");
            System.out.println("2. 고객명");
            System.out.println("3. 종료");
            System.out.print("검색 옵션을 선택하세요 (1 또는 2): ");
            int searchOption = input.nextInt();
            String searchWord = "";
            
            switch (searchOption) {
                case 1:
                    System.out.println("도서명 입력");
                    break;
                case 2:
                    System.out.println("이름 입력");
                    break;
                case 3:
                    System.out.println("프로그램 종료");// 프로그램 종료
                    
                    continue;
            }
            
            searchWord = input2.nextLine();
            bList.runSQL(searchOption, searchWord);	
        }
    }
}
 